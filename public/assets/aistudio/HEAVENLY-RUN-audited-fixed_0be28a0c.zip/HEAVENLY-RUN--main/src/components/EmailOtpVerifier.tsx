import React, { useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { CheckCircle2, ShieldCheck, AlertTriangle, LogIn } from 'lucide-react';
import { auth } from '../services/firebase';

interface EmailOtpVerifierProps {
  email: string;
  onEmailChange?: (email: string) => void;
  purpose: string;
  isVerified: boolean;
  onVerified: (email: string, token: string) => void;
  disabled?: boolean;
}

/** Uses the project's existing Firebase Auth identity; no second email vendor or API key. */
export const EmailOtpVerifier: React.FC<EmailOtpVerifierProps> = ({ email, onVerified, disabled = false }) => {
  const [authEmail, setAuthEmail] = useState<string | null>(auth.currentUser?.email?.toLowerCase() || null);
  const [emailVerified, setEmailVerified] = useState(Boolean(auth.currentUser?.emailVerified));

  useEffect(() => onAuthStateChanged(auth, (user) => {
    setAuthEmail(user?.email?.toLowerCase() || null);
    setEmailVerified(Boolean(user?.emailVerified));
  }), []);

  const cleanEmail = email.trim().toLowerCase();
  const matches = Boolean(cleanEmail && emailVerified && authEmail && cleanEmail === authEmail);

  useEffect(() => {
    if (matches) onVerified(cleanEmail, 'firebase-auth');
    else onVerified('', '');
  }, [matches, cleanEmail, onVerified]);

  return (
    <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2 font-tech" aria-live="polite">
      <div className="flex items-center gap-2 text-xs font-bold tracking-wider uppercase">
        {matches ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <ShieldCheck className="w-4 h-4 text-blue-400" />}
        <span className={matches ? 'text-emerald-300' : 'text-blue-300'}>{matches ? 'EMAIL VERIFIED WITH CONNECTED ACCOUNT' : 'VERIFY USING YOUR CONNECTED ACCOUNT'}</span>
      </div>
      {matches ? (
        <p className="text-xs text-emerald-200">Firebase confirms access to {cleanEmail}. You can submit this form.</p>
      ) : (
        <p className="text-xs text-white/60 flex items-start gap-2">
          <LogIn className="w-4 h-4 shrink-0 text-blue-300" />
          Sign in using the existing website sign-in button, then enter the same verified email address here. No additional provider or email API is required.
        </p>
      )}
      {!matches && authEmail && cleanEmail && authEmail !== cleanEmail && (
        <p className="text-xs text-amber-300 flex items-center gap-1"><AlertTriangle className="w-3.5 h-3.5" /> This email does not match your signed-in account ({authEmail}).</p>
      )}
      {disabled && <p className="text-[10px] text-white/40">Verification changes are disabled while submitting.</p>}
    </div>
  );
};
