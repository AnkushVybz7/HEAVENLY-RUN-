# HEAVENLY-RUN ENERGY — deployment checklist

## Existing authentication
- The website continues using its existing Firebase Authentication project and configured providers.
- A verified Firebase Auth email must match the email entered on Flavour Lab and Contact forms.
- No Resend account, email API key, or additional authentication provider is required for this flow.
- This is account-based email verification, not a six-digit OTP. Google/Firebase confirms the signed-in account's email verification claim.

## Firestore security
- Publish the included `firestore.rules` to the same Firebase project's Firestore database.
- Subscriber records are readable/editable/deletable only by the verified founder account.
- Public visitors cannot read subscriber or contact records.
- Form creation requires a signed-in account with a verified email matching the submitted email.
- Admin access is derived from the Firebase Auth identity, never from localStorage or a client-side password.

## Netlify
- Build command: `npm run build`
- Publish directory: `dist`
- Deploy the extracted project folder (the folder containing package.json and index.html).
- No new environment variables are required for the current Firebase-authenticated form flow.

## Important limitations
- First-50 ranking is intentionally not calculated in the browser. A trustworthy global ranking requires a trusted server-side transaction/counter. The current client must not claim an exact rank.
- Test sign-in, form submission and Firestore rules after deploying the updated rules.
